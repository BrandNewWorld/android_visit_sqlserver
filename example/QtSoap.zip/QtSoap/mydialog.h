#ifndef MYDIALOG_H
#define MYDIALOG_H

#include <QApplication>
#include <QPushButton>
#include <QLineEdit>
#include <QHBoxLayout>
#include <QDialog>

#include "WebService1Soap.nsmap"
#include "soapWebService1SoapProxy.h"

class MyDialog :public QDialog
{
public:
    //MyDialog()=default;
    MyDialog(QWidget *parent=0):QDialog(parent)
    {
        btn =new QPushButton("invoke");
        line = new QLineEdit;
        connect(btn,SIGNAL(clicked()),this,SLOT(OnClicked()));
        QHBoxLayout *layout = new QHBoxLayout;
        layout->addWidget(line);
        layout->addWidget(btn);
        setLayout(layout);
    }

private:
    QPushButton *btn;
    QLineEdit *line;
    public slots:
    //void OnClicked(){
    void OnClicked(){
        struct soap _soap;
        soap_init(&_soap);
        soap_set_mode(&_soap, SOAP_C_UTFSTRING);
        WebService1SoapProxy mySoap;
        _tempuri__HelloWorld req;
        _tempuri__HelloWorldResponse res;
        mySoap.HelloWorld_(&req, res);
        //std::string msgStr("hello");
        //req.msg = &msgStr;
       // _soap._tempuri__HelloWorld(&req,&res);
       // QString serverStr = "http://192.168.2.23/WebService1.asmx";
       // soap_call___tempuri__HelloWorld(&_soap, _serverStr, "", &req, &res);
        QString str = QString::fromUtf8(res.HelloWorldResult->c_str());
        line->setText(str);
    }
};

#endif // MYDIALOG_H
