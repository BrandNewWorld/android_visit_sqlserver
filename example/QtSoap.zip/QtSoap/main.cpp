#include "mainwindow.h"
#include <QApplication>
#include <QDebug>
#include <vector>

#include "WebService1Soap.nsmap"
#include "soapWebService1SoapProxy.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    WebService1SoapProxy mySoap; // soapWebService1SoapProxy.h声明
    _tempuri__HelloWorld req;
    _tempuri__HelloWorldResponse res;
    mySoap.HelloWorld_(&req, res);
    QString str = QString::fromUtf8(res.HelloWorldResult->c_str());
    qDebug () << str;
    _tempuri__insertData reqID;
    _tempuri__insertDataResponse resIDR;
    std::string _id = "1";
    std::string _name = "Tang";
    std::string _age = "25";
    reqID.id = &_id;
    reqID.name = &_name;
    reqID.age = &_age;
    mySoap.insertData_(&reqID, resIDR);
    //QString ins_str = QString::fromUtf8(resIDR.insertDataResult);
    //qDebug () << str;
    _tempuri__selectallData sel;
    _tempuri__selectallDataResponse selr;
    mySoap.selectallData_(&sel, selr);
    std::vector<std::string>::iterator iter = selr.selectallDataResult->string.begin();
    for(;iter != selr.selectallDataResult->string.end();iter++)
    {
        QString sel_str = QString::fromStdString((*iter));
        qDebug () << sel_str;
     }

    w.show();

    return a.exec();
}
