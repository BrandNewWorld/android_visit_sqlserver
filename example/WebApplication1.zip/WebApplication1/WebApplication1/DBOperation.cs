﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;


namespace WebApplication1
{
    public class DBOperation
    {
        public static SqlConnection sqlCon;  //用于连接数据库

        //将下面的引号之间的内容换成上面记录下的属性中的连接字符串Integrated Security=True
        private String ConServerStr = @"Data Source=Mengyuming;Initial Catalog=test_db;Persist Security Info=True;User ID=sa;Password=123456";

        //默认构造函数
        public DBOperation()
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection();
                sqlCon.ConnectionString = ConServerStr;
                sqlCon.Open();
            }
        }

        //关闭/销毁函数，相当于Close()
        public void Dispose()
        {
            if (sqlCon != null)
            {
                sqlCon.Close();
                sqlCon = null;
            }
        }

        public List<string> selectAll()
        {
            List<string> list = new List<string>();
            try
            {
                string sql = "select * from student";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    for (int i = 0; i < 3; i++)
                    {
                        list.Add(reader[i].ToString());
                    }
                }
                reader.Close();
                cmd.Dispose();
            }
            catch (Exception)
            {

            }
            return list;
        }

        //longi——经度  lati——纬度
        public bool message_add(string id, string name, string age) //创建一条信息
        {
            bool result = false;
            try
            {
                string sqls = "insert into student values('"  + id + "','" + name + "','" + age + "')";
                SqlCommand cmd = new SqlCommand(sqls, sqlCon);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                result = true;
            }
            catch (Exception e)
            {
            }
            return result;
        }

        public bool message_delete(string id)
        {
            bool result = false;
            try
            {
                string sql = "delete from student where id=" + id;
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                result = true;
            }
            catch (Exception)
            {

            }
            return result;
        }
    }
}